﻿namespace PatternDepenInjectUnityWcf.Contract
{
    public interface ILogger
    {
        string Log(string msg);
    }
}