import { HasClaimDirective } from './has-claim.directive';

describe('HasClaimDirective', () => {
  it('should create an instance', () => {
    const directive = new HasClaimDirective();
    expect(directive).toBeTruthy();
  });
});
